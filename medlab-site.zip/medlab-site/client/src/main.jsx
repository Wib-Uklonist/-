import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { CartProvider } from './context/CartContext';
import Layout from './components/Layout';
import Home from './pages/Home';
import Analyses from './pages/Analyses';
import AnalysisDetail from './pages/AnalysisDetail';
import Cart from './pages/Cart';
import Contacts from './pages/Contacts';
import './styles.css';

function NotFound() { return <section className="section page-section"><div className="container empty-state"><h2>Страница не найдена</h2><a href="/">Вернуться на главную</a></div></section>; }
ReactDOM.createRoot(document.getElementById('root')).render(<React.StrictMode><BrowserRouter><CartProvider><Routes><Route element={<Layout/>}><Route path="/" element={<Home/>}/><Route path="/analyses" element={<Analyses/>}/><Route path="/analyses/:slug" element={<AnalysisDetail/>}/><Route path="/cart" element={<Cart/>}/><Route path="/contacts" element={<Contacts/>}/><Route path="*" element={<NotFound/>}/></Route></Routes></CartProvider></BrowserRouter></React.StrictMode>);
