# МедЛаб — React + Express + PostgreSQL

## Структура

- `client` — React, Vite, React Router
- `server` — Express REST API
- `server/src/db/init.js` — создание таблиц и начальное наполнение каталога
- `client/public/images` — изображения сайта

## Требования

Node.js 20+ и PostgreSQL 14+.

## Запуск

1. Создайте базу данных PostgreSQL:

```sql
CREATE DATABASE medlab;
```

2. Скопируйте `server/.env.example` в `server/.env` и укажите параметры подключения:

```env
PORT=5000
DATABASE_URL=postgresql://postgres:3352@localhost:5432/medlab
CLIENT_URL=http://localhost:5173
```

3. Установите зависимости из корня проекта:

```bash
npm run install:all
```

4. Создайте таблицы и тестовые записи:

```bash
npm run db:init --prefix server
```

5. Запустите frontend и backend одновременно:

```bash
npm run dev
```

Frontend: http://localhost:5173  
Backend: http://localhost:5000  
Проверка API и БД: http://localhost:5000/api/health

## API

- `GET /api/analyses` — список анализов
- `GET /api/analyses?search=кровь` — поиск
- `GET /api/analyses?category=general` — фильтр по категории
- `GET /api/analyses/categories` — категории
- `GET /api/analyses/:slug` — подробности анализа
- `POST /api/orders` — оформление заявки с позициями заказа
- `POST /api/contacts` — отправка сообщения из формы контактов

## Изображения

Положите изображения в `client/public/images`:

- `hero-lab.jpg` — главное изображение первого слайда
- `hero-doctor.jpg` — второй слайд
- `hero-results.jpg` — третий слайд
- `lab-team.jpg` — блок на главной странице
- `about-lab.jpg` — страница «О лаборатории»
- `blood-test.jpg`, `urine-test.jpg`, `biochemistry.jpg`, `hormones.jpg`, `vitamin-d.jpg`, `lab-tubes.jpg` — изображения анализов
- `analysis-placeholder.jpg` — запасное изображение

Если изображений нет, сайт продолжит работать, но вместо них будут пустые/запасные области. Рекомендуется добавить свои файлы с указанными именами.

## Страницы

1. Главная — слайдер, преимущества, популярные исследования.
2. Каталог анализов — поиск, фильтр категорий, карточки.
3. Страница анализа — описание, подготовка, срок, добавление в корзину.
4. Корзина — изменение количества, удаление, отправка заявки.
5. Контакты — реквизиты, форма обратной связи и информация о лаборатории.

Страница отдельного анализа открывается динамически из каталога и использует общий шаблон карточки исследования. Раздел «О лаборатории» ведёт к информационному блоку на странице контактов.

Данные заявок сохраняются в PostgreSQL. Перед публикацией добавьте серверную защиту от спама, политику обработки персональных данных, реальные контакты и адрес, настройте HTTPS и резервное копирование БД.
