import { Router } from 'express';
import { pool } from '../db/pool.js';

const router = Router();
router.post('/', async (req, res, next) => {
  const { customerName, phone, email = '', comment = '', items = [] } = req.body;
  if (!customerName?.trim() || !phone?.trim() || !Array.isArray(items) || !items.length) {
    return res.status(400).json({ message: 'Заполните имя, телефон и добавьте хотя бы один анализ' });
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const ids = items.map(item => Number(item.id));
    if (ids.some(id => !Number.isInteger(id) || id < 1)) throw new Error('Некорректный состав заказа');
    const products = await client.query('SELECT id,title,price FROM analyses WHERE id=ANY($1::int[])', [ids]);
    const byId = new Map(products.rows.map(item => [item.id, item]));
    const normalized = items.map(item => {
      const product = byId.get(Number(item.id));
      const quantity = Math.max(1, Math.min(20, Number(item.quantity) || 1));
      if (!product) throw new Error('Один из анализов больше недоступен');
      return { ...product, quantity };
    });
    const total = normalized.reduce((sum, item) => sum + Number(item.price) * item.quantity, 0);
    const order = await client.query(
      'INSERT INTO orders(customer_name,phone,email,comment,total) VALUES($1,$2,$3,$4,$5) RETURNING id,total,created_at',
      [customerName.trim(), phone.trim(), email.trim(), comment.trim(), total]
    );
    for (const item of normalized) {
      await client.query(
        'INSERT INTO order_items(order_id,analysis_id,title,price,quantity) VALUES($1,$2,$3,$4,$5)',
        [order.rows[0].id, item.id, item.title, item.price, item.quantity]
      );
    }
    await client.query('COMMIT');
    res.status(201).json({ message: 'Заявка оформлена', order: order.rows[0] });
  } catch (error) {
    await client.query('ROLLBACK');
    if (error.message.includes('анализ') || error.message.includes('заказ')) return res.status(400).json({ message: error.message });
    next(error);
  } finally { client.release(); }
});

export default router;
