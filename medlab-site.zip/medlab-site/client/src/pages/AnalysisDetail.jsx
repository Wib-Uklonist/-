import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Clock3, FileText, ShieldCheck } from 'lucide-react';
import { api } from '../api';
import { useCart } from '../context/CartContext';
export default function AnalysisDetail() {
  const { slug } = useParams();
  const [item,setItem] = useState(null);
  const [error,setError] = useState('');
  const { add,items } = useCart();
  useEffect(() => { api.analysis(slug).then(setItem).catch(err => setError(err.message)); }, [slug]);
  if (error) return <section className="section page-section"><div className="container empty-state error-state">{error}<p><Link to="/analyses" className="text-link">Вернуться в каталог</Link></p></div></section>;
  if (!item) return <section className="section page-section"><div className="container empty-state">Загружаем информацию…</div></section>;
  const inCart = items.some(product => product.id === item.id);
  return <section className="section page-section"><div className="container"><Link to="/analyses" className="back-link"><ArrowLeft size={17}/> Все анализы</Link><div className="detail-layout"><div className="detail-image"><img src={item.image} alt="" onError={e => {e.currentTarget.src='/images/placeholder.svg';}}/></div><div className="detail-content"><span className="eyebrow">{item.categoryName}</span><h1>{item.title}</h1><p className="detail-description">{item.description}</p><div className="detail-price-row"><strong>{Number(item.price).toLocaleString('ru-RU')} ₽</strong><span><Clock3 size={17}/> Срок выполнения: {item.duration}</span></div><button className={inCart ? 'button button-added' : 'button'} onClick={() => add(item)}>{inCart ? 'Уже в корзине' : 'Добавить в корзину'}</button><div className="detail-assurance"><ShieldCheck/><span>Все исследования выполняются с соблюдением стандартов качества.</span></div></div></div><div className="detail-info"><div><FileText/><h3>Описание исследования</h3><p>{item.description}</p></div><div><Clock3/><h3>Подготовка и сроки</h3><p>{item.preparation}</p><p>Ориентировочный срок готовности: {item.duration}.</p></div></div></div></section>;
}
