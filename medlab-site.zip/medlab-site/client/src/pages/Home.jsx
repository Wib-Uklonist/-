import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ShieldCheck, Microscope, HeartPulse, Clock3, ChevronLeft, ChevronRight, CheckCircle2 } from 'lucide-react';
import { api } from '../api';
import AnalysisCard from '../components/AnalysisCard';
import SectionTitle from '../components/SectionTitle';

const slides = [
  { tag: 'Забота о здоровье начинается здесь', title: 'Здоровье — это просто', text: 'Сдавайте анализы комфортно, получайте точные результаты и будьте уверены в своём здоровье.', image: '/images/hero-lab.jpg', action: 'Выбрать анализы' },
  { tag: 'Современная лабораторная диагностика', title: 'Точность в каждом исследовании', text: 'Современное оборудование и специалисты, которым можно доверять.', image: '/images/hero-doctor.jpg', action: 'О лаборатории' },
  { tag: 'Быстро. Удобно. Надёжно.', title: 'Результаты без лишнего ожидания', text: 'Большинство популярных исследований готовы уже на следующий день.', image: '/images/hero-results.jpg', action: 'Смотреть каталог' }
];

export default function Home() {
  const [slide, setSlide] = useState(0);
  const [popular, setPopular] = useState([]);
  useEffect(() => { api.analyses({ popular: 'true' }).then(data => setPopular(data.slice(0,4))).catch(() => {}); }, []);
  useEffect(() => { const timer = setInterval(() => setSlide(value => (value + 1) % slides.length), 6500); return () => clearInterval(timer); }, []);
  const current = slides[slide];
  return <>
    <section className="hero"><div className="container hero-inner"><div className="hero-copy"><span className="eyebrow">{current.tag}</span><h1>{current.title}</h1><p>{current.text}</p><div className="hero-buttons"><Link className="button" to={slide === 1 ? '/contacts#about' : '/analyses'}>{current.action}<ArrowRight size={18}/></Link><a className="hero-phone" href="tel:+78005553535">8 800 555-35-35</a></div><div className="hero-dots">{slides.map((item,index) => <button key={item.title} className={index === slide ? 'active' : ''} onClick={() => setSlide(index)} aria-label={`Слайд ${index+1}`}/>)}</div></div><div className="hero-visual"><img src={current.image} alt="Медицинская лаборатория" onError={e => { e.currentTarget.src='/images/placeholder.svg'; }}/><div className="hero-stamp"><ShieldCheck size={24}/><span><b>Контроль качества</b><small>на каждом этапе</small></span></div></div><button className="slider-arrow prev" onClick={() => setSlide((slide+slides.length-1)%slides.length)} aria-label="Предыдущий"><ChevronLeft/></button><button className="slider-arrow next" onClick={() => setSlide((slide+1)%slides.length)} aria-label="Следующий"><ChevronRight/></button></div></section>
    <section className="benefits"><div className="container benefits-grid"><div><Microscope/><span><b>Современное оборудование</b><small>Точные и надёжные исследования</small></span></div><div><Clock3/><span><b>Быстрые результаты</b><small>Удобные сроки выполнения</small></span></div><div><HeartPulse/><span><b>Забота о каждом</b><small>Внимательный подход к пациентам</small></span></div><div><ShieldCheck/><span><b>Контроль качества</b><small>Проверка на всех этапах</small></span></div></div></section>
    <section className="section"><div className="container"><div className="section-heading-row"><SectionTitle eyebrow="Популярные исследования" title="Часто выбирают" text="Самые востребованные анализы — в одном месте."/><Link to="/analyses" className="text-link">Весь каталог <ArrowRight size={17}/></Link></div><div className="analysis-grid">{popular.map(item => <AnalysisCard key={item.id} item={item}/>)}</div>{popular.length === 0 && <div className="empty-state">Каталог скоро появится. Проверьте подключение к серверу.</div>}</div></section>
    <section className="promo-section"><div className="container promo-box"><div><span className="eyebrow">МедЛаб — рядом</span><h2>Проверить здоровье проще, чем кажется</h2><p>Выберите необходимые исследования в каталоге или оставьте заявку — мы поможем разобраться.</p><Link to="/analyses" className="button button-light">Перейти к анализам <ArrowRight size={18}/></Link></div><div className="promo-art"><img src="/images/lab-team.jpg" alt="Специалисты лаборатории" onError={e => { e.currentTarget.style.display='none'; }}/><div className="promo-check"><CheckCircle2/> Забота о вашем здоровье</div></div></div></section>
  </>;
}
