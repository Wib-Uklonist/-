import { Link, NavLink } from 'react-router-dom';
import { Activity, Menu, ShoppingBag, X, Phone } from 'lucide-react';
import { useState } from 'react';
import { useCart } from '../context/CartContext';

const links = [['Главная','/'],['Анализы','/analyses'],['О лаборатории','/contacts#about'],['Контакты','/contacts']];
export default function Header() {
  const [opened, setOpened] = useState(false);
  const { count } = useCart();
  return <header className="header"><div className="container header-inner">
    <Link to="/" className="logo" onClick={() => setOpened(false)}><span className="logo-mark"><Activity size={25}/></span><span>Мед<span>Лаб</span><small>ЛАБОРАТОРИЯ ЗДОРОВЬЯ</small></span></Link>
    <nav className={opened ? 'nav nav-open' : 'nav'}>{links.map(([label,path]) => <NavLink key={path} to={path} end={path === '/'} onClick={() => setOpened(false)}>{label}</NavLink>)}</nav>
    <div className="header-actions"><a className="header-phone" href="tel:+78005553535"><Phone size={16}/> 8 800 555-35-35</a><Link className="cart-link" to="/cart" aria-label="Корзина"><ShoppingBag size={20}/>{count > 0 && <b>{count}</b>}</Link><button className="menu-toggle" onClick={() => setOpened(!opened)} aria-label="Меню">{opened ? <X/> : <Menu/>}</button></div>
  </div></header>;
}
