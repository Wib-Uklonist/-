import { Link } from 'react-router-dom';
import { ArrowUpRight, Clock3 } from 'lucide-react';
import { useCart } from '../context/CartContext';
export default function AnalysisCard({ item }) {
  const { add, items } = useCart();
  const inCart = items.some(product => product.id === item.id);
  return <article className="analysis-card"><Link to={`/analyses/${item.slug}`} className="analysis-image"><img src={item.image || '/images/placeholder.svg'} alt="" onError={e => { e.currentTarget.src = '/images/placeholder.svg'; }}/><span>{item.categoryName}</span></Link><div className="analysis-card-body"><Link to={`/analyses/${item.slug}`} className="analysis-title">{item.title}</Link><p>{item.description}</p><div className="analysis-meta"><span><Clock3 size={15}/>{item.duration}</span><strong>{Number(item.price).toLocaleString('ru-RU')} ₽</strong></div><div className="card-actions"><button className={inCart ? 'button button-added' : 'button button-small'} onClick={() => add(item)}>{inCart ? 'В корзине' : 'Добавить'}</button><Link to={`/analyses/${item.slug}`} className="round-link" aria-label="Подробнее"><ArrowUpRight size={19}/></Link></div></div></article>;
}
