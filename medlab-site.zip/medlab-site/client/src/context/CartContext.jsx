import { createContext, useContext, useEffect, useMemo, useState } from 'react';

const CartContext = createContext(null);
export function CartProvider({ children }) {
  const [items, setItems] = useState(() => {
    try { return JSON.parse(localStorage.getItem('medlab-cart') || '[]'); } catch { return []; }
  });
  useEffect(() => localStorage.setItem('medlab-cart', JSON.stringify(items)), [items]);
  const add = analysis => setItems(current => current.some(item => item.id === analysis.id) ? current : [...current, { ...analysis, quantity: 1 }]);
  const remove = id => setItems(current => current.filter(item => item.id !== id));
  const setQuantity = (id, quantity) => setItems(current => current.map(item => item.id === id ? { ...item, quantity: Math.max(1, Math.min(20, Number(quantity) || 1)) } : item));
  const clear = () => setItems([]);
  const total = items.reduce((sum, item) => sum + Number(item.price) * item.quantity, 0);
  const value = useMemo(() => ({ items, add, remove, setQuantity, clear, total, count: items.reduce((sum, item) => sum + item.quantity, 0) }), [items, total]);
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}
export const useCart = () => useContext(CartContext);
