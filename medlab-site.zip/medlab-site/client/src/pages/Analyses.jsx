import { useEffect, useMemo, useState } from 'react';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { api } from '../api';
import AnalysisCard from '../components/AnalysisCard';
import SectionTitle from '../components/SectionTitle';

export default function Analyses() {
  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  useEffect(() => { api.categories().then(setCategories).catch(() => {}); }, []);
  useEffect(() => {
    setLoading(true); setError('');
    const timer = setTimeout(() => api.analyses({ search, category }).then(setItems).catch(err => setError(err.message)).finally(() => setLoading(false)), 250);
    return () => clearTimeout(timer);
  }, [search, category]);
  const hasFilters = search || category;
  return <section className="section page-section"><div className="container"><SectionTitle eyebrow="Каталог исследований" title="Анализы и диагностика" text="Подберите нужное исследование и добавьте его в корзину."/><div className="catalog-toolbar"><label className="search-box"><Search size={19}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Поиск по названию анализа"/>{search && <button onClick={() => setSearch('')} aria-label="Очистить"><X size={17}/></button>}</label><div className="filter-label"><SlidersHorizontal size={17}/> Категория</div><select value={category} onChange={e => setCategory(e.target.value)}><option value="">Все категории</option>{categories.map(item => <option value={item.slug} key={item.id}>{item.name}</option>)}</select>{hasFilters && <button className="reset-filter" onClick={() => {setSearch('');setCategory('');}}>Сбросить</button>}</div><div className="catalog-count">Найдено исследований: <b>{items.length}</b></div>{loading ? <div className="empty-state">Загружаем каталог…</div> : error ? <div className="empty-state error-state">{error}</div> : items.length ? <div className="analysis-grid">{items.map(item => <AnalysisCard key={item.id} item={item}/>)}</div> : <div className="empty-state">По вашему запросу ничего не найдено. Попробуйте изменить фильтры.</div>}</div></section>;
}
