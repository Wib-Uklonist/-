import { Router } from 'express';
import { pool } from '../db/pool.js';

const router = Router();
router.post('/', async (req, res, next) => {
  const { customerName, phone, message = '' } = req.body;
  if (!customerName?.trim() || !phone?.trim()) return res.status(400).json({ message: 'Укажите имя и телефон' });
  try {
    await pool.query('INSERT INTO contact_requests(customer_name,phone,message) VALUES($1,$2,$3)', [customerName.trim(), phone.trim(), message.trim()]);
    res.status(201).json({ message: 'Сообщение отправлено. Мы скоро свяжемся с вами.' });
  } catch (error) { next(error); }
});
export default router;
