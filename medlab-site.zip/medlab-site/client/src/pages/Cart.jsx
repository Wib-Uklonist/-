import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Minus, Plus, Trash2, ShoppingBag, CheckCircle2 } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { api } from '../api';
import SectionTitle from '../components/SectionTitle';
export default function Cart() {
  const { items,remove,setQuantity,total,clear } = useCart();
  const [form,setForm] = useState({ customerName:'',phone:'',email:'',comment:'' });
  const [status,setStatus] = useState('');
  const [loading,setLoading] = useState(false);
  const change = e => setForm(current => ({...current,[e.target.name]:e.target.value}));
  const submit = async e => {
    e.preventDefault(); setLoading(true); setStatus('');
    try { const result = await api.createOrder({...form,items:items.map(item => ({id:item.id,quantity:item.quantity}))}); clear(); setStatus(`${result.message}. Номер заявки: ${result.order.id}`); setForm({customerName:'',phone:'',email:'',comment:''}); }
    catch(error) { setStatus(error.message); }
    finally { setLoading(false); }
  };
  return <section className="section page-section"><div className="container"><SectionTitle eyebrow="Ваш выбор" title="Корзина" text="Проверьте выбранные исследования и оставьте заявку."/>{status && <div className="form-message"><CheckCircle2 size={19}/>{status}</div>}{!items.length ? <div className="cart-empty"><ShoppingBag size={44}/><h3>В корзине пока пусто</h3><p>Выберите необходимые исследования в каталоге.</p><Link to="/analyses" className="button">Перейти в каталог</Link></div> : <div className="cart-layout"><div className="cart-items">{items.map(item => <article className="cart-item" key={item.id}><img src={item.image} alt="" onError={e => {e.currentTarget.src='/images/placeholder.svg';}}/><div className="cart-item-info"><Link to={`/analyses/${item.slug}`}>{item.title}</Link><small>{item.duration}</small><strong>{Number(item.price).toLocaleString('ru-RU')} ₽</strong></div><div className="quantity-control"><button onClick={() => setQuantity(item.id,item.quantity-1)} aria-label="Уменьшить"><Minus size={15}/></button><span>{item.quantity}</span><button onClick={() => setQuantity(item.id,item.quantity+1)} aria-label="Увеличить"><Plus size={15}/></button></div><button className="remove-button" onClick={() => remove(item.id)} aria-label="Удалить"><Trash2 size={18}/></button></article>)}<button className="clear-cart" onClick={clear}>Очистить корзину</button></div><aside className="checkout-card"><h3>Оформление заявки</h3><form onSubmit={submit}><label>Ваше имя<input name="customerName" value={form.customerName} onChange={change} required placeholder="Как к вам обращаться"/></label><label>Телефон<input name="phone" type="tel" value={form.phone} onChange={change} required placeholder="+7 (___) ___-__-__"/></label><label>Email<input name="email" type="email" value={form.email} onChange={change} placeholder="name@example.com"/></label><label>Комментарий<textarea name="comment" value={form.comment} onChange={change} rows="3" placeholder="Дополнительная информация"/></label><div className="checkout-total"><span>Итого</span><strong>{total.toLocaleString('ru-RU')} ₽</strong></div><button className="button button-full" disabled={loading}>{loading ? 'Отправляем…' : 'Оставить заявку'}</button><small className="form-legal">Нажимая кнопку, вы соглашаетесь на обработку персональных данных.</small></form></aside></div>}</div></section>;
}
