import dotenv from 'dotenv';
import { pool } from './pool.js';
dotenv.config();

const schema = `
CREATE TABLE IF NOT EXISTS categories (
  id SERIAL PRIMARY KEY,
  name VARCHAR(120) NOT NULL UNIQUE,
  slug VARCHAR(140) NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS analyses (
  id SERIAL PRIMARY KEY,
  title VARCHAR(220) NOT NULL,
  slug VARCHAR(240) NOT NULL UNIQUE,
  description TEXT NOT NULL,
  preparation TEXT NOT NULL DEFAULT 'Специальная подготовка не требуется. Уточните рекомендации при записи.',
  duration VARCHAR(80) NOT NULL DEFAULT '1 рабочий день',
  price NUMERIC(10,2) NOT NULL,
  old_price NUMERIC(10,2),
  category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
  image VARCHAR(255) NOT NULL DEFAULT '/images/analysis-placeholder.jpg',
  popular BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY,
  customer_name VARCHAR(160) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  email VARCHAR(180),
  comment TEXT,
  total NUMERIC(10,2) NOT NULL,
  status VARCHAR(40) NOT NULL DEFAULT 'new',
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS order_items (
  id SERIAL PRIMARY KEY,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  analysis_id INTEGER REFERENCES analyses(id) ON DELETE SET NULL,
  title VARCHAR(220) NOT NULL,
  price NUMERIC(10,2) NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS contact_requests (
  id SERIAL PRIMARY KEY,
  customer_name VARCHAR(160) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  message TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);`;

const seed = [
  ['Общие анализы','general','Общий анализ крови с лейкоцитарной формулой','general-blood-test','Комплексное исследование клеточного состава крови. Помогает оценить общее состояние организма.','1 рабочий день',650,true,'/images/blood-test.jpg'],
  ['Общие анализы','general','Общий анализ мочи','urine-test','Лабораторное исследование физических и химических характеристик мочи.','1 рабочий день',450,true,'/images/urine-test.jpg'],
  ['Биохимия','biochemistry','Биохимический анализ крови','biochemistry-blood','Исследование основных биохимических показателей крови.','1–2 рабочих дня',1850,true,'/images/biochemistry.jpg'],
  ['Гормоны','hormones','ТТГ (тиреотропный гормон)','tsh','Исследование уровня тиреотропного гормона для оценки функции щитовидной железы.','1 рабочий день',590,true,'/images/hormones.jpg'],
  ['Витамины','vitamins','Витамин D (25-OH)','vitamin-d','Определение концентрации 25-OH витамина D в крови.','2 рабочих дня',1450,true,'/images/vitamin-d.jpg'],
  ['Инфекции','infections','Комплекс: ферритин + железо','ferritin-iron','Исследование показателей обмена железа.','2 рабочих дня',1200,false,'/images/lab-tubes.jpg'],
  ['Гормоны','hormones','Тестостерон общий','testosterone','Определение уровня общего тестостерона в сыворотке крови.','1–2 рабочих дня',750,false,'/images/hormones.jpg'],
  ['Биохимия','biochemistry','Глюкоза в крови','glucose','Определение уровня глюкозы в венозной крови.','1 рабочий день',350,false,'/images/biochemistry.jpg']
];

try {
  await pool.query(schema);
  for (const [category, categorySlug, title, slug, description, duration, price, popular, image] of seed) {
    const categoryResult = await pool.query(
      'INSERT INTO categories(name, slug) VALUES($1,$2) ON CONFLICT(slug) DO UPDATE SET name=EXCLUDED.name RETURNING id',
      [category, categorySlug]
    );
    await pool.query(
      `INSERT INTO analyses(title,slug,description,duration,price,category_id,popular,image)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT(slug) DO NOTHING`,
      [title, slug, description, duration, price, categoryResult.rows[0].id, popular, image]
    );
  }
  console.log('База данных подготовлена');
} catch (error) {
  console.error(error);
  process.exitCode = 1;
} finally {
  await pool.end();
}
