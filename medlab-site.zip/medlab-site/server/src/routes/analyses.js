import { Router } from 'express';
import { pool } from '../db/pool.js';

const router = Router();
const fields = `a.id,a.title,a.slug,a.description,a.preparation,a.duration,a.price,a.old_price AS "oldPrice",a.image,a.popular,c.name AS "categoryName",c.slug AS "categorySlug"`;

router.get('/', async (req, res, next) => {
  try {
    const { search = '', category = '', popular = '' } = req.query;
    const result = await pool.query(
      `SELECT ${fields} FROM analyses a LEFT JOIN categories c ON c.id=a.category_id
       WHERE ($1='' OR a.title ILIKE '%'||$1||'%' OR a.description ILIKE '%'||$1||'%')
       AND ($2='' OR c.slug=$2) AND ($3='' OR a.popular=($3='true')) ORDER BY a.popular DESC,a.id`,
      [search, category, popular]
    );
    res.json(result.rows);
  } catch (error) { next(error); }
});

router.get('/categories', async (req, res, next) => {
  try {
    const result = await pool.query('SELECT id,name,slug FROM categories ORDER BY name');
    res.json(result.rows);
  } catch (error) { next(error); }
});

router.get('/:slug', async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT ${fields} FROM analyses a LEFT JOIN categories c ON c.id=a.category_id WHERE a.slug=$1`,
      [req.params.slug]
    );
    if (!result.rowCount) return res.status(404).json({ message: 'Анализ не найден' });
    res.json(result.rows[0]);
  } catch (error) { next(error); }
});

export default router;
