import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import analysesRouter from './routes/analyses.js';
import ordersRouter from './routes/orders.js';
import contactsRouter from './routes/contacts.js';
import { pool } from './db/pool.js';

dotenv.config();
const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173' }));
app.use(express.json({ limit: '1mb' }));
app.get('/api/health', async (req, res, next) => {
  try { await pool.query('SELECT 1'); res.json({ status: 'ok', database: 'connected' }); }
  catch (error) { next(error); }
});
app.use('/api/analyses', analysesRouter);
app.use('/api/orders', ordersRouter);
app.use('/api/contacts', contactsRouter);
app.use((req, res) => res.status(404).json({ message: 'Маршрут не найден' }));
app.use((error, req, res, next) => {
  console.error(error);
  res.status(500).json({ message: 'Внутренняя ошибка сервера' });
});
const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`API запущен: http://localhost:${port}`));
