const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

async function request(path, options = {}) {
  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...options.headers }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || 'Не удалось выполнить запрос');
  return data;
}

export const api = {
  analyses: params => request(`/analyses${params ? `?${new URLSearchParams(params)}` : ''}`),
  analysis: slug => request(`/analyses/${slug}`),
  categories: () => request('/analyses/categories'),
  createOrder: body => request('/orders', { method: 'POST', body: JSON.stringify(body) }),
  sendContact: body => request('/contacts', { method: 'POST', body: JSON.stringify(body) })
};
